const got = require('got');
const crypto = require('crypto');

const github_base = 'https://api.github.com';

//protection set for master branch
const protections = {
    "required_status_checks": null,
    "enforce_admins": true,
    "required_pull_request_reviews": null,
    "restrictions": {
        "users": [
            "jcappello"
        ],
        "teams": [
            "justice-league"
        ]
    },
    "required_linear_history": true,
    "allow_force_pushes": true,
    "allow_deletions": true
};

exports.handler = async (event) => {

    console.log("Event: " + JSON.stringify(event, null, 2));
    console.log("Body: " + event.body);

    try {
        let secret = event.headers['X-Hub-Signature'];
        if (secret && verify_signature(secret, event.body)) {

            let body = JSON.parse(event.body);

            if (body.hasOwnProperty('action') && body.hasOwnProperty('repository')) {
                //check if a repo was created
                if (body['action'] == 'created') {
                    let repo = body.repository['full_name'];
                    console.log(repo)
                    const protectResponse = await protectMaster(repo);
                    const issueResponse = await notifyIssue(repo, protectResponse);
                }
                return {statusCode: 200, body: JSON.stringify('Success')};
            } else {
                return {
                    statusCode: 500,
                    body: JSON.stringify('Request body has no action. Make sure your webhook is enabled to send repository events.')
                };
            }
        }
    } catch (error){
        return { statusCode: 500, body: JSON.stringify(error) };
    }

};

const initializeRequest = () => {
    let encodedCredentials = new Buffer.from(
        process.env.username + ":" + process.env.token
    );
    let authHeader = "Basic " + encodedCredentials.toString("base64");
    return {
        json: {},
        headers: {
            'Authorization': authHeader,
            'User-Agent': 'script',
            'Content-Type': 'application/json'
        },
        throwHttpErrors: false
    };
};

const protectMaster =  async (repo) => {
    try {
        let request = initializeRequest();
        request.json = protections;
        const response = await got.put(`${github_base}/repos/${repo}/branches/master/protectio`, request);
        if (response.statusCode !== 200) {
            return {statusCode: response.statusCode, body: JSON.stringify(response.body)};
        }
        return response.body;
    } catch (error) {
        return { statusCode: 500, body: error };
    }
};

const notifyIssue =  async (repo, protections) => {
    try {
        let request = initializeRequest();
        let protect = protections;
        request.json = {
            'title': 'Master branch protection enabled.',
            'body': '@jcappello \n The following permissions have been set: \n `' + protect + '`'
        };
        const response = await got.post(`${github_base}/repos/${repo}/issues`, request);
        if (response.statusCode !== 201) {
            return {statusCode: response.statusCode, body: JSON.stringify(response.body)};
        }
        return response.body;
    } catch (error) {
        return { statusCode: 500, body: error };
    }
};

function verify_signature(secret, payload_body){
    let hash = crypto.createHmac('sha1', process.env.secret)
        .update(payload_body)
        .digest('hex');
    let signature = 'sha1=' + hash;
    console.log('Compare: ' + signature);
    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(secret))){
        return { statusCode: 500, body: JSON.stringify('Signature does not match. Aborting operation.') };
    } else return true;
};